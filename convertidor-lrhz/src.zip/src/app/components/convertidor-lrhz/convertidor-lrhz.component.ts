import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lrhz-convertidor-lrhz',
  templateUrl: './convertidor-lrhz.component.html',
  styleUrls: ['./convertidor-lrhz.component.css']
})
export class ConvertidorLrhzComponent implements OnInit {

  cantidad = 0;
  tengo = '';
  quiero = '';
  total = 0;

  monedas: string[] = ['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'CNY', 'HKD', 'INR'];

  constructor() { }

  ngOnInit(): void {
    this.convertir(); // Llamada inicial a convertir al cargar el componente
  }

  convertir(): void {
    switch (this.tengo) {
      case 'USD':
        if (this.quiero === 'USD') {
          this.total = this.cantidad;
        }
        if (this.quiero === 'EUR') {
          this.total = this.cantidad * 0.98;
        }
        if (this.quiero === 'LIBRA') {
          this.total = this.cantidad * 0.78;
        }
        if (this.quiero === 'MXN') {
          this.total = this.cantidad * 20.02;        }
        if (this.quiero === 'AUD') {
          this.total = this.cantidad * 1.36;
        }
        if (this.quiero === 'CAD') {
          this.total = this.cantidad * 1.27;
        }
        if (this.quiero === 'CHF') {
          this.total = this.cantidad * 0.93;
        }
        if (this.quiero === 'CNY') {
          this.total = this.cantidad * 6.45;
        }
        if (this.quiero === 'HKD') {
          this.total = this.cantidad * 7.78;
        }
        if (this.quiero === 'INR') {
          this.total = this.cantidad * 74.39;
        }
        
        break;
      case 'EUR':
        if (this.quiero === 'USD') {
          this.total = this.cantidad / 0.98;
        }
        if (this.quiero === 'EUR') {
          this.total = this.cantidad;
        }
        if (this.quiero === 'LIBRA') {
          this.total = this.cantidad * (0.78 / 0.98);
        }
        
        break;
      case 'LIBRA':
        if (this.quiero === 'USD') {
          this.total = this.cantidad / 0.78;
        }
        if (this.quiero === 'EUR') {
          this.total = this.cantidad * (0.98 / 0.78);
        }
        if (this.quiero === 'LIBRA') {
          this.total = this.cantidad;
        }
        break;
    }
  }

}
