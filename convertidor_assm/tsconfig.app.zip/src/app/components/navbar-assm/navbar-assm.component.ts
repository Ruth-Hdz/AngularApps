import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assm-navbar-assm',
  templateUrl: './navbar-assm.component.html',
  styleUrls: ['./navbar-assm.component.css']
})
export class NavbarAssmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
